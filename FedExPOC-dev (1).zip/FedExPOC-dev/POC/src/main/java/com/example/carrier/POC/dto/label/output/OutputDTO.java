package com.example.carrier.POC.dto.label.output;

import lombok.Data;

import java.util.List;

@Data
public class OutputDTO {
    private List<TransactionShipmentsDTO> transactionShipments;
}
