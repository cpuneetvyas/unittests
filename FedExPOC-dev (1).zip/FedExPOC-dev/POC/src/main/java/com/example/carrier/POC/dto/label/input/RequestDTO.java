package com.example.carrier.POC.dto.label.input;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class RequestDTO {
    @JsonProperty("requestedShipment")
    private RequestedShipmentDTO requestedShipment;

    @JsonProperty("labelResponseOptions")
    private String labelResponseOptions;

    @JsonProperty("accountNumber")
    private AccountNumberDTO accountNumber;

}
