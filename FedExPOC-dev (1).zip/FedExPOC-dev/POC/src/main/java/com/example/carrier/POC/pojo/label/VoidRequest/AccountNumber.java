package com.example.carrier.POC.pojo.label.VoidRequest;


import lombok.Data;

@Data
public class AccountNumber {
    private String value;
}
