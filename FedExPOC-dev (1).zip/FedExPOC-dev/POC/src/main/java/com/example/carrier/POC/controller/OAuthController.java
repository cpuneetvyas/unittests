package com.example.carrier.POC.controller;

import com.example.carrier.POC.dto.oAuth.ResponseDTO;
import com.example.carrier.POC.service.oAuth.OAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
public class OAuthController {

    @Autowired
    private OAuthService service;
    @PostMapping("/token")
    public ResponseDTO getOAuthToken() {
//        System.out.println(body.get("grant_type"));
//        String grantType = body.get("grant_type");
//        String clientId = body.get("client_id");
//        String clientSecret = body.get("client_secret");

        ResponseDTO responseDTO = service.getOAuthToken();
        return responseDTO;
    }
}
