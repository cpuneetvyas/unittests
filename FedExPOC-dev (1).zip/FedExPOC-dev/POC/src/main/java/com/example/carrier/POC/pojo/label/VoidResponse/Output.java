package com.example.carrier.POC.pojo.label.VoidResponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.util.List;

@Data
@JsonIgnoreProperties
public class Output {
    private boolean cancelledShipment;
    private boolean  cancelledHistory;
    private String successMessage;

    private List<Alert> alerts;
}
