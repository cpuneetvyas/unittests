package com.example.carrier.POC.exception;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class CarrierApiException extends RuntimeException {
    private byte[] exceptionData;
    public CarrierApiException(byte[] exception) {
        super();
        this.exceptionData = exception;
    }
}
