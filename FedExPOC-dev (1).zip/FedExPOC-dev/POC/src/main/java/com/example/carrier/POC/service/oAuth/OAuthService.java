package com.example.carrier.POC.service.oAuth;

import com.example.carrier.POC.dto.oAuth.ResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;


@Service
public class OAuthService {

    @Autowired
    private RestTemplate restTemplate;

    // loading data from .yml file
    @Value("${OAuth.grantType}")
    private String grantType;
    @Value("${OAuth.clientId}")
    private String clientId;
    @Value("${OAuth.clientSecret}")
    private String clientSecret;
    @Value("${OAuth.URL}")
    private String OAuthUrl;

    public ResponseDTO getOAuthToken(){
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED.toString());
        headers.add("Accept", MediaType.APPLICATION_JSON.toString());

        MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
        requestBody.add("grant_type", grantType);
        requestBody.add("client_id", clientId);
        requestBody.add("client_secret", clientSecret);
        HttpEntity<MultiValueMap<String, String>> formEntity = new HttpEntity<>(requestBody, headers);

        ResponseEntity<?> responseEntity = restTemplate.postForEntity(OAuthUrl, formEntity, ResponseDTO.class);
        ResponseDTO responseDTO = (ResponseDTO) responseEntity.getBody();

        return responseDTO;
    }
}
