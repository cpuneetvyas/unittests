package com.example.carrier.POC.dto.label.output;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.http.ResponseEntity;

//@Builder
@Data
public class LabelResponseDTO{
    @JsonProperty("transactionId")
    private String transactionId;
    @JsonProperty("output")
    private OutputDTO output;

}
