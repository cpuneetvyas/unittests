package com.example.carrier.POC.pojo.label.input;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
@Data
public class AddressPoJo {
        @NotEmpty(message = "streetLines is required")
        private String[] streetLines;
        @NotEmpty(message = "city is required")
        private String city;
        @NotEmpty(message = "stateOrProvinceCode is required")
        private String stateOrProvinceCode;
        @NotEmpty(message = "postalCode is required")
        private String postalCode;
        @NotEmpty(message = "countryCode is required")
        private String countryCode;
        @NotEmpty(message = "residential is required")
        private String residential;
}
