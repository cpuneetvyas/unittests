package com.example.carrier.POC.dto.label.output;

import lombok.Data;

import java.util.List;

@Data
public class PieceDTO {
    private String trackingNumber;
    private String deliveryDatestamp;
    private List<DocumentDTO> packageDocuments;
    private String currency;
    private String baseRateAmount;
    private String additionalChargesDiscount;
    private String netChargeAmount;
    private String codCollectionAmount;

}
