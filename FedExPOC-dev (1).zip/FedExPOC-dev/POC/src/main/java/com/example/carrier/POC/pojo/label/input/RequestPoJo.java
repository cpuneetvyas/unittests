package com.example.carrier.POC.pojo.label.input;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
@Valid
public class RequestPoJo {

    @Valid
    private ProfilePoJo shipper;

    @Valid
    private ProfilePoJo[] recipients;

    @NotEmpty(message="pickupType is required")
    private String pickupType;

    @NotEmpty(message="serviceType is required")
    private String serviceType;

    @NotEmpty(message="packagingType is required")
    private String packagingType;

    @NotEmpty(message="totalWeight is required")
    private String totalWeight;

    @NotEmpty(message="shippingChargesPaymentType is required")
    private String shippingChargesPaymentType;

    @NotEmpty(message="labelFormatType is required")
    private String labelFormatType;

    @NotEmpty(message="labelOrder is required")
    private String labelOrder;

    @NotEmpty(message="labelStockType is required")
    private String labelStockType;

    @NotEmpty(message="labelRotation is required")
    private String labelRotation;

    @NotEmpty(message="imageType cannot be empty")
    private String imageType;

    @NotEmpty(message="labelPrintingOrientation is required")
    private String labelPrintingOrientation;

    @NotNull(message="returnedDispositionDetail is required")
    private Boolean returnedDispositionDetail;

    @NotEmpty(message="requestedPackageLineItems is required")
    private PackagePoJo[] requestedPackageLineItems;

    @NotEmpty(message="labelResponseOptions is required")
    private String labelResponseOptions;

    @NotEmpty(message="accountNumber is required")
    private String accountNumber;
}
