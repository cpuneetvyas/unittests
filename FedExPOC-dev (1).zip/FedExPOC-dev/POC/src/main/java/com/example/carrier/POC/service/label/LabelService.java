package com.example.carrier.POC.service.label;

import com.example.carrier.POC.dto.label.input.*;
import com.example.carrier.POC.dto.label.output.DocumentDTO;
import com.example.carrier.POC.dto.label.output.LabelResponseDTO;
import com.example.carrier.POC.dto.label.output.PieceDTO;
import com.example.carrier.POC.dto.label.output.TransactionShipmentsDTO;
import com.example.carrier.POC.exception.CarrierApiException;
import com.example.carrier.POC.pojo.label.input.PackagePoJo;
import com.example.carrier.POC.pojo.label.input.ProfilePoJo;
import com.example.carrier.POC.pojo.label.input.RequestPoJo;
import com.example.carrier.POC.pojo.label.output.LabelResponsePoJo;
import com.example.carrier.POC.pojo.label.output.TransactionShipmentsPoJo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.http.converter.HttpMessageConverter;
import org.springframework.stereotype.Service;
import org.springframework.web.ErrorResponse;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.GZIPInputStream;

@Service
public class LabelService {

    @Value("${Label.URL}")
    private String FedExCreateLabelUrl;
    @Autowired
    private RestTemplate restTemplate;

    public LabelResponseDTO callFedExCreateLabel(RequestPoJo requestBody, String authToken ) throws CarrierApiException {
        try {
//            System.out.println(authToken);
            RequestDTO parsedRequestBody = parseFedExRequestLabel(requestBody);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setBearerAuth(authToken);

            HttpEntity<RequestDTO> formEntity = new HttpEntity<>(parsedRequestBody, headers);
            ResponseEntity<?> responseEntity = restTemplate.postForEntity(FedExCreateLabelUrl, formEntity, LabelResponseDTO.class);
            LabelResponseDTO responseDTO = (LabelResponseDTO) responseEntity.getBody();
            return responseDTO;
        } catch(HttpClientErrorException.BadRequest exception) {
//            System.out.println("byte_aaray"+ exception.getResponseBodyAsByteArray());
            throw new CarrierApiException(exception.getResponseBodyAsByteArray());
        }
    }


    private RequestDTO parseFedExRequestLabel(RequestPoJo requestBody) {

        AddressDTO shipperAddressDTO = AddressDTO.builder()
                .streetLines(requestBody.getShipper().getAddress().getStreetLines())
                .city(requestBody.getShipper().getAddress().getCity())
                .stateOrProvinceCode(requestBody.getShipper().getAddress().getStateOrProvinceCode())
                .postalCode(requestBody.getShipper().getAddress().getPostalCode())
                .countryCode(requestBody.getShipper().getAddress().getCountryCode())
                .residential(requestBody.getShipper().getAddress().getResidential())
                .build();

        ContactDTO shipperContactDTO = ContactDTO.builder()
                .emailAddress(requestBody.getShipper().getContact().getEmailAddress())
                .phoneNumber(requestBody.getShipper().getContact().getPhoneNumber())
                .personName(requestBody.getShipper().getContact().getPersonName())
                .phoneExtension(requestBody.getShipper().getContact().getPhoneExtension())
                .companyName(requestBody.getShipper().getContact().getCompanyName())
                .build();


        ProfileDTO shipperDTO = ProfileDTO.builder()
                .contact(shipperContactDTO)
                .address(shipperAddressDTO)
                .build();

        ProfilePoJo[] recipientPoJoS = requestBody.getRecipients();
        List<ProfileDTO> recipientDTOS = new ArrayList<>();
        for(ProfilePoJo recipientPojo: recipientPoJoS ){
            AddressDTO recipientAddressDTO = AddressDTO.builder()
                    .streetLines(recipientPojo.getAddress().getStreetLines())
                    .city(recipientPojo.getAddress().getCity())
                    .stateOrProvinceCode(recipientPojo.getAddress().getStateOrProvinceCode())
                    .postalCode(recipientPojo.getAddress().getPostalCode())
                    .countryCode(recipientPojo.getAddress().getCountryCode())
                    .residential(recipientPojo.getAddress().getResidential())
                    .build();

            ContactDTO recipientContactDTO = ContactDTO.builder()
                    .emailAddress(recipientPojo.getContact().getEmailAddress())
                    .phoneNumber(recipientPojo.getContact().getPhoneNumber())
                    .personName(recipientPojo.getContact().getPersonName())
                    .phoneExtension(recipientPojo.getContact().getPhoneExtension())
                    .companyName(recipientPojo.getContact().getCompanyName())
                    .build();

            ProfileDTO recipientDTO = ProfileDTO.builder()
                    .contact(recipientContactDTO)
                    .address(recipientAddressDTO)
                    .build();

            recipientDTOS.add(recipientDTO);
        }

        ChargeDTO chargeDTO = ChargeDTO.builder()
                .paymentType(requestBody.getShippingChargesPaymentType())
                .build();

        LabelDTO labelDTO = LabelDTO.builder()
                .labelFormatType(requestBody.getLabelFormatType())
                .labelOrder(requestBody.getLabelOrder())
                .labelRotation(requestBody.getLabelRotation())
                .labelPrintingOrientation(requestBody.getLabelPrintingOrientation())
                .labelStockType(requestBody.getLabelStockType())
                .imageType(requestBody.getImageType())
                .returnedDispositionDetail(requestBody.getReturnedDispositionDetail())
                .build();



        List<PackageDTO> packageDTOS = new ArrayList<>();
        PackagePoJo[] packagePoJos = requestBody.getRequestedPackageLineItems();
        for(PackagePoJo packagePoJo: packagePoJos) {
            PackageWeightDTO packageWeightDTO = PackageWeightDTO.builder()
                    .units(packagePoJo.getPackageWeight().getUnits())
                    .value(packagePoJo.getPackageWeight().getValue())
                    .build();

            PackageDTO packageDTO = PackageDTO.builder()
                    .weight(packageWeightDTO)
                    .build();

            packageDTOS.add(packageDTO);
        }


        RequestedShipmentDTO requestedShipmentDTO = RequestedShipmentDTO.builder()
                .shipper(shipperDTO)
                .recipients(recipientDTOS)
                .pickupType(requestBody.getPickupType())
                .serviceType(requestBody.getServiceType())
                .packagingType(requestBody.getPackagingType())
                .totalWeight(requestBody.getTotalWeight())
                .shippingChargesPayment(chargeDTO)
                .labelSpecification(labelDTO)
                .requestedPackageLineItems(packageDTOS)
                .build();

        AccountNumberDTO accountNumberDTO = AccountNumberDTO.builder()
                .value(requestBody.getAccountNumber())
                .build();

        return  RequestDTO.builder()
                .requestedShipment(requestedShipmentDTO)
                .labelResponseOptions(requestBody.getLabelResponseOptions())
                .accountNumber(accountNumberDTO)
                .build();
    }

    public LabelResponsePoJo parseFedExResponse(LabelResponseDTO body){
        TransactionShipmentsDTO transactionShipmentsDTO = body.getOutput().getTransactionShipments().get(0);
        PieceDTO pieceDTO = transactionShipmentsDTO.getPieceResponses().get(0);
        DocumentDTO packageDTO = pieceDTO.getPackageDocuments().get(0);

        return LabelResponsePoJo.builder()
                .transactionId(body.getTransactionId())
                .trackingId(transactionShipmentsDTO.getMasterTrackingNumber())
                .serviceType(transactionShipmentsDTO.getServiceType())
                .totalAmount(pieceDTO.getBaseRateAmount())
                .Label(packageDTO.getEncodedLabel())
                .build();
    }
}
