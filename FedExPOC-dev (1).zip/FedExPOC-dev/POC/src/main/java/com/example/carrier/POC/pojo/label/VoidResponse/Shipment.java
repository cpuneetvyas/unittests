package com.example.carrier.POC.pojo.label.VoidResponse;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class Shipment {
    private boolean cancellation;
    private boolean cancellatedHistory;
}
