package com.example.carrier.POC.controller;

import com.example.carrier.POC.dto.oAuth.ResponseDTO;
import com.example.carrier.POC.pojo.label.VoidRequest.ShipmentCancellationRequest;
import com.example.carrier.POC.pojo.label.VoidResponse.CancelResponse;
import com.example.carrier.POC.pojo.label.VoidResponse.Package;
import com.example.carrier.POC.pojo.label.VoidResponse.Shipment;
import com.example.carrier.POC.pojo.label.VoidResponse.ShipmentCancellationResponse;
import com.example.carrier.POC.service.CarrierApiService;
import com.example.carrier.POC.service.oAuth.OAuthService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

import static org.springframework.web.servlet.function.ServerResponse.status;

@RestController
public class ShipmentController {

    @Autowired
    private CarrierApiService carrierApiService;
    @Autowired
    private OAuthService oAuthService;
    @PutMapping("/cancel")
    public ResponseEntity cancelShipment(
            @RequestBody ShipmentCancellationRequest cancellationRequest) {

        ResponseDTO authResponse = oAuthService.getOAuthToken();
        String authToken = authResponse.getAccessToken();

        ShipmentCancellationResponse response = carrierApiService.cancelShipment(cancellationRequest, authToken);


        Shipment shipment;
        Package package_ = Package.builder()
                .transactionId(response.getTransactionId())
                .trackingNo(cancellationRequest.getTrackingNumber())
                .build();

        if (response.getOutput().isCancelledShipment()) {
            shipment = Shipment.builder()
                    .cancellation(true)
                    .cancellatedHistory(true)
                    .build();
            CancelResponse cancelResponse = CancelResponse.builder()
                    .message("Shipment cancelled successfully..")
                    .shipment(shipment)
                    .packageList(Arrays.asList(package_))
                    .build();

            return new ResponseEntity<>(cancelResponse, HttpStatus.OK);

        } else {
            shipment = Shipment.builder()
                    .cancellation(false)
                    .cancellatedHistory(false)
                    .build();
            CancelResponse cancelResponse = CancelResponse.builder()
                    .message("Shipment failed to cancel")
                    .shipment(shipment)
                    .packageList(Arrays.asList(package_))
                    .build();
            return new ResponseEntity(cancelResponse,HttpStatus.OK);
        }

    }
}
