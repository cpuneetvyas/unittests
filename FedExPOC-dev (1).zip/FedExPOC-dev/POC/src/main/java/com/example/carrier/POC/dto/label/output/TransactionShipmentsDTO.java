package com.example.carrier.POC.dto.label.output;

import lombok.Data;

import java.util.List;

@Data
public class TransactionShipmentsDTO {
    private String masterTrackingNumber;
    private String serviceType;
    private String shipDatestamp;
    private String serviceName;
    private String serviceCategory;
    private List<PieceDTO> pieceResponses;
}
