package com.example.carrier.POC.pojo.label.input;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;


@Data
public class ContactPoJo {
    @NotEmpty(message = "personName is required")
    private String personName;
    @Email(message = "emailAddress is required")
    private String emailAddress;
    @NotEmpty(message = "phoneExtension is required")
    private String phoneExtension;
    @NotEmpty(message = "phoneNumber is required")
    private String phoneNumber;
    @NotEmpty(message = "companyName is required")
    private String companyName;
}
