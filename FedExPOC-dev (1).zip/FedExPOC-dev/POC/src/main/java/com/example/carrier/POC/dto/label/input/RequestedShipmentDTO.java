package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Builder
@Data
public class RequestedShipmentDTO {
    private ProfileDTO shipper;
    private List<ProfileDTO> recipients;
    private String pickupType;
    private String serviceType;
    private String packagingType;
    private String totalWeight;
    private ChargeDTO shippingChargesPayment;
    private LabelDTO labelSpecification;
    private List<PackageDTO> requestedPackageLineItems;

}

