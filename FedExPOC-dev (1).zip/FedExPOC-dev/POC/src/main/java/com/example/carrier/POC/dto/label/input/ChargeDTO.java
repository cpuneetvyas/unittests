package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.jackson.Jacksonized;

//@Builder
@Data
@Builder
@Jacksonized
public class ChargeDTO {
    private String paymentType;
}
