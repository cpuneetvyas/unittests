package com.example.carrier.POC.pojo.label.VoidResponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties
public class ShipmentCancellationResponse {
    private String transactionId;

    private String customerTransactionId;
    private Output output;



}