package com.example.carrier.POC.exception;

import com.example.carrier.POC.pojo.label.exception.ErrorResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

@RestControllerAdvice
public class ValidationHandler {
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public Map<String, String> handleInvalidArgument(MethodArgumentNotValidException exception){
        Map<String , String> errorMap = new HashMap<>();
        exception.getBindingResult().getFieldErrors().forEach(error -> {
            errorMap.put(error.getField(), error.getDefaultMessage());
        });
        return errorMap;
    }

    @ExceptionHandler(CarrierApiException.class)
    public ResponseEntity<ErrorResponse> carrierApiHandler(CarrierApiException carrierApiException) throws IOException {
        StringBuilder deCompressErrors = deCompress(carrierApiException.getExceptionData());
//        System.out.println("byte_aaray"+carrierApiException.getExceptionData());
//        System.out.println("decompressed" + deCompressErrors);
        JSONObject jsonErrors = new JSONObject(deCompressErrors.toString());
        JSONArray jsonArray = new JSONArray(jsonErrors.getJSONArray("errors"));
        JSONObject jsonError = jsonArray.getJSONObject(0);

        String errorCode = jsonError.getString("code");
        String errorMessage = jsonError.getString("message");
        String errorInTransactionId = jsonErrors.getString("transactionId");

        ErrorResponse errorResponse = ErrorResponse.builder()
                .transactionId(errorInTransactionId)
                .code(errorCode)
                .message(errorMessage)
                .build();

        return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
    }

    private static StringBuilder deCompress(byte[] str) throws IOException {
        StringBuilder decodedString = new StringBuilder();
        ByteArrayInputStream byteA = new ByteArrayInputStream(str);
        final GZIPInputStream gzipInput = new GZIPInputStream(byteA);
        InputStreamReader reader = new InputStreamReader(gzipInput);
        BufferedReader br = new BufferedReader(reader);
        String readed="";
        while ((readed = br.readLine()) != null) {
            decodedString.append(readed);
        }
        return decodedString;
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ExceptionHandler(Exception.class)
    public String defaultHandler(Exception exception) {
        return exception.getMessage();
    }
}
