package com.example.carrier.POC.pojo.label.VoidResponse;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder

public class CancelResponse {
    private String message;
    private Shipment shipment;
    private List<Package> packageList;

}
