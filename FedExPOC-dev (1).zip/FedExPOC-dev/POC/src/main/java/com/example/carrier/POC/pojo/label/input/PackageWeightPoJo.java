package com.example.carrier.POC.pojo.label.input;

import lombok.Data;

@Data
public class PackageWeightPoJo {
    private String units;
    private String value;
}
