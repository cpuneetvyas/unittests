package com.example.carrier.POC.controller;

import com.example.carrier.POC.dto.label.output.LabelResponseDTO;
import com.example.carrier.POC.dto.oAuth.ResponseDTO;
import com.example.carrier.POC.exception.CarrierApiException;
import com.example.carrier.POC.pojo.label.input.RequestPoJo;
import com.example.carrier.POC.pojo.label.output.LabelResponsePoJo;
import com.example.carrier.POC.service.label.LabelService;
import com.example.carrier.POC.service.oAuth.OAuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
public class LabelController {

    @Autowired
    private LabelService labelService;

    @Autowired
    private OAuthService oAuthService;


    @PostMapping("/create-label")
    public LabelResponsePoJo createLabel( @RequestHeader("Authorization") String token, @Valid @RequestBody RequestPoJo body){
        String bearerToken = token.split(" ")[1];
        LabelResponseDTO response = labelService.callFedExCreateLabel(body, bearerToken);
        LabelResponsePoJo labelResponsePoJo = labelService.parseFedExResponse(response);
        return  labelResponsePoJo;
    }

    @GetMapping("/test")
    public String testConnection(){
        return "This works!!!";
    }

}
