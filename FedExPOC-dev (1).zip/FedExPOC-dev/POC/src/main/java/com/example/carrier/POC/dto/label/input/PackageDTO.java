package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;
import lombok.extern.jackson.Jacksonized;


@Builder
@Data
@Jacksonized
public class PackageDTO {
    private PackageWeightDTO weight;
}

