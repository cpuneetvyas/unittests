package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ProfileDTO {
    private AddressDTO address;
    private ContactDTO contact;
}
