package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class AddressDTO {
    private String[] streetLines;
    private String city;
    private String stateOrProvinceCode;
    private String postalCode;
    private String countryCode;
    private String residential;
}
