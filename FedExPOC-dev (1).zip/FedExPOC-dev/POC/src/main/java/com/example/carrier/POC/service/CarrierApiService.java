package com.example.carrier.POC.service;

import com.example.carrier.POC.pojo.label.VoidRequest.ShipmentCancellationRequest;
import com.example.carrier.POC.pojo.label.VoidResponse.ShipmentCancellationResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CarrierApiService {

    private static final String FEDEX_API_URL = "https://apis-sandbox.fedex.com/ship/v1/shipments/cancel";

    @Autowired
    private RestTemplate restTemplate;

    public ShipmentCancellationResponse cancelShipment(ShipmentCancellationRequest shipmentCancellationRequest, String authToken) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.setBearerAuth(authToken);
        System.out.println("Auth Token is: " + authToken);
        System.out.println("Request body:" + shipmentCancellationRequest);
        HttpEntity<?> httpEntity = new HttpEntity<>(shipmentCancellationRequest, headers);


        ResponseEntity<ShipmentCancellationResponse> responseEntity = restTemplate.exchange(FEDEX_API_URL,
                HttpMethod.PUT,
                httpEntity,
                new ParameterizedTypeReference<ShipmentCancellationResponse>() {}
        );

        ShipmentCancellationResponse response = responseEntity.getBody();
        return response;

    }
}