package com.example.carrier.POC.pojo.label.VoidResponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties
public class Alert {
    private String code;
    private String alertType;
    @JsonIgnoreProperties(ignoreUnknown = true)
    private String message;
}
