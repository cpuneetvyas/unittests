package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class ContactDTO {
    private String personName;
    private String emailAddress;
    private String phoneExtension;
    private String phoneNumber;
    private String companyName;
}
