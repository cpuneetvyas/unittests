package com.example.carrier.POC.pojo.label.output;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class TransactionShipmentsPoJo {
    private String trackingId;
    private String totalAmount;
    private String serviceType;
    private String Label;
}
