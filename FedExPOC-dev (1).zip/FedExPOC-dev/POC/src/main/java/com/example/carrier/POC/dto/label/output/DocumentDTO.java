package com.example.carrier.POC.dto.label.output;

import lombok.Data;

@Data
public class DocumentDTO {
    private String contentType;
    private String encodedLabel;
}
