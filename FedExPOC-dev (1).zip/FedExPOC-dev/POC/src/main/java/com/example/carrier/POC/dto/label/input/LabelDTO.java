package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;

@Builder
@Data
public class LabelDTO {
    private String labelFormatType;
    private String labelOrder;
    private String labelStockType;
    private String labelRotation;
    private String imageType;
    private String labelPrintingOrientation;
    private Boolean returnedDispositionDetail;
}
