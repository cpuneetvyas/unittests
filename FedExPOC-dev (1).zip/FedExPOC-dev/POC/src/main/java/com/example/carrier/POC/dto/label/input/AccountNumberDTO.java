package com.example.carrier.POC.dto.label.input;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.jackson.Jacksonized;

@Data
@Builder
@Jacksonized
public class AccountNumberDTO {
    private String value;
}
