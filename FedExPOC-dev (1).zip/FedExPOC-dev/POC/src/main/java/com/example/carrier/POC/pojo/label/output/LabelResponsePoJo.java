package com.example.carrier.POC.pojo.label.output;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Builder
@Data
public class LabelResponsePoJo {
    private String transactionId;
    private String trackingId;
    private String totalAmount;
    private String serviceType;
    private String Label;

}

