package com.example.carrier.POC.pojo.label.exception;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ErrorResponse {
    private String transactionId;
    private String code;
    private String message;
}
