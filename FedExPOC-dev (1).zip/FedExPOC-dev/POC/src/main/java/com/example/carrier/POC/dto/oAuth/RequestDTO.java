package com.example.carrier.POC.dto.oAuth;

import lombok.Data;

@Data
public class RequestDTO {
    private String grantType;
    private String clientId;
    private String clientSecret;
}
