package com.example.carrier.POC.pojo.label.input;

import jakarta.validation.Valid;
import lombok.Data;

@Data
public class ProfilePoJo {
    @Valid
    private AddressPoJo address;
    @Valid
    private ContactPoJo contact;
}
