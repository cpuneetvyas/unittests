package com.example.carrier.POC.pojo.label.VoidRequest;


import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class ShipmentCancellationRequest {
//    @JsonProperty("accountNumber")
    private AccountNumber accountNumber;
//    @JsonProperty("trackingNumber")
    private String trackingNumber;
    private boolean emailShipment;
    private String senderCountryCode;
    private String deletionControl;


}