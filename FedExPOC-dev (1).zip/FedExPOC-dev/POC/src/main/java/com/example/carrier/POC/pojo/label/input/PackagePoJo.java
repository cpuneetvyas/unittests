package com.example.carrier.POC.pojo.label.input;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class PackagePoJo {
    @JsonProperty("weight")
    private PackageWeightPoJo packageWeight;
}
